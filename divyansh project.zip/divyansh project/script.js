const annualToggle = document.getElementById('annualToggle');

annualToggle.addEventListener('change', function() {
    const prices = document.querySelectorAll('.price');
    
    prices.forEach(price => {
        const currentPrice = price.innerText;
        const monthlyPrice = currentPrice.match(/\d+/)[0];
        const annualPrice = monthlyPrice * 12;
        
        if (annualToggle.checked) {
            price.innerText = '$' + annualPrice + '/year';
        } else {
            price.innerText = '$' + monthlyPrice + '/month';
        }
    });
});
